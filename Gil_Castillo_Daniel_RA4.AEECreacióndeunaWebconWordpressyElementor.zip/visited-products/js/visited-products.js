document.addEventListener('DOMContentLoaded', function () {
    const visitedProducts = JSON.parse(localStorage.getItem('visitedProducts')) || [];
   
    // Registrar productos visitados
    const productTitle = document.querySelector('.product_title');
    if (productTitle) {
       
        const productLink = window.location.href;
        const product = { title: productTitle.textContent, link: productLink };
        if (!visitedProducts.find(p => p.link === productLink)) {
            visitedProducts.push(product);
            localStorage.setItem('visitedProducts', JSON.stringify(visitedProducts));
        }
    }

    // Mostrar productos visitados
    const visitedProductsList = document.getElementById('visited-products-list');
    if (visitedProductsList) {
        visitedProductsList.innerHTML = visitedProducts.map(p => `<li><a href="${p.link}">${p.title}</a></li>`).join('');
    }
});

