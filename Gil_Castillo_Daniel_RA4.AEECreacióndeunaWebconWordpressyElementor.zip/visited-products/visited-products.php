<?php
/*
Plugin Name: Visited Products
Description: Registra y muestra los productos visitados por los clientes.
Version: 1.0
Author: DANI GIL
*/



// Registrar scripts y estilos
function vp_enqueue_scripts() {
    wp_enqueue_script('vp-script', plugins_url('js/visited-products.js', __FILE__), array('jquery'), null, true);
    wp_localize_script('vp-script', 'vp_ajax', array('ajax_url' => admin_url('admin-ajax.php')));
}
add_action('wp_enqueue_scripts', 'vp_enqueue_scripts');

// Shortcode para mostrar productos visitados
function vp_display_visited_products() {
    return '<div id="visited-products-list"></div>';
}
add_shortcode('visited_products', 'vp_display_visited_products');

// AJAX para recuperar productos
function vp_get_visited_products() {
    $products = isset($_POST['products']) ? $_POST['products'] : array();
    echo json_encode($products);
    wp_die();
}
add_action('wp_ajax_nopriv_vp_get_visited_products', 'vp_get_visited_products');
add_action('wp_ajax_vp_get_visited_products', 'vp_get_visited_products');


function vp_append_to_page_content($content) {
    // Verifica si estás en la página deseada
    if (is_page('productos')) { // Cambia 'productos' por el slug de tu página
        $extra_content = do_shortcode('[visited_products]');
        $content .= $extra_content; // Agrega el contenido del shortcode al final
    }
    return $content;
}
add_filter('the_content', 'vp_append_to_page_content');

